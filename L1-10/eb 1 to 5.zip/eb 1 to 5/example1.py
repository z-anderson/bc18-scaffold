going = True
while going:
	print('why?')
	usrInput = input()
	if usrInput=='q':
		going = False